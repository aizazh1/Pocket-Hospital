package com.rafi.project;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HomeBottom extends Fragment{
    private RecyclerView recyclerViewApp;
    LinearLayoutManager layoutManager;
    RecyclerViewAdapterApointment adapter;

    DatabaseHelper dbHelper;
    private ArrayList<Appointment> appointmentValues = new ArrayList<>();
    TextView tvEmptyMesg;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_appointment_bottom, container, false);
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvEmptyMesg = view.findViewById(R.id.tvEmptyMesg);
        recyclerViewApp = view.findViewById(R.id.rv_appointment);

        layoutManager = new LinearLayoutManager(getContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerViewApp.setLayoutManager(layoutManager);

        getData();

        adapter = new RecyclerViewAdapterApointment(getContext(),appointmentValues, recyclerViewApp );
        recyclerViewApp.setAdapter(adapter);
        checkEmpty();

        recyclerViewApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Image on Bottom Right Fragment clicked", Toast.LENGTH_LONG).show();
            }
        });



    }

    public void getData(){
        dbHelper = new DatabaseHelper(getContext());

        Commons.userAppointments = AppointmentDB.getAppointment(dbHelper);
        appointmentValues = Commons.userAppointments;

    }


    public void updateRecycler(String dr_name){
        if (dr_name.equalsIgnoreCase("all")){
            Commons.userAppointments = AppointmentDB.getAppointment(dbHelper);
            appointmentValues = Commons.userAppointments;
            adapter = new RecyclerViewAdapterApointment(getContext(), appointmentValues, recyclerViewApp);
            recyclerViewApp.setAdapter(adapter);


        }else{
            ArrayList<Appointment> res = AppointmentDB.getAppointmentDoc(dbHelper, dr_name);
            appointmentValues = res;
            adapter = new RecyclerViewAdapterApointment(getContext(),appointmentValues, recyclerViewApp);
            recyclerViewApp.setAdapter(adapter);
        }
        checkEmpty();
    }

    public void checkEmpty(){
        if (appointmentValues.isEmpty()){
            tvEmptyMesg.setVisibility(View.VISIBLE);
        }else {
            tvEmptyMesg.setVisibility(View.INVISIBLE);
        }

    }

}
