package com.rafi.project;

import android.content.Context;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Commons {
    static Patient user;
    static ArrayList<Reminder> userReminder = new ArrayList<>();
    static ArrayList<Appointment> userAppointments = new ArrayList<>();


    static public void displayToast(Context context, String msg){
        Toast.makeText( context, msg,Toast.LENGTH_LONG).show();
    }
}
