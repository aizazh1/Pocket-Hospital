package com.rafi.project;

import android.app.IntentService;
import android.app.IntentService;
import android.content.Intent;
import android.graphics.Bitmap;
import android.util.Log;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.BitmapRequestListener;

import java.io.ByteArrayOutputStream;

public class MyIntentService extends IntentService {
    // One needs to implement a constructor for the class and call its superclass
    // with the name of the intent service (setting it with a string):
    public MyIntentService() {
        super("MyIntentService");
    }

    // The onHandleIntent() method is where you place the code that needs to be executed on
    // a separate thread, such as downloading a file from a server. When the code has
    // finished executing, the thread is terminated and the service is stopped automatically.
    protected void onHandleIntent(Intent intent) {
        Log.d("IntentService", "Service Started");

        AndroidNetworking.get(intent.getStringExtra("url"))
                .setTag("imageRequestTag")
                .setPriority(Priority.MEDIUM)
                .setBitmapMaxHeight(200)
                .setBitmapMaxWidth(200)
                .setBitmapConfig(Bitmap.Config.ARGB_8888)
                .build()
                .getAsBitmap(new BitmapRequestListener() {
                    @Override
                    public void onResponse(Bitmap bitmap) {
                        // do anything with bitmap


                        Log.d("IntentService", "Image Downloaded");
                        // Converting the Bitmap to byte array
                        ByteArrayOutputStream mByteArrayOutputStream = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, mByteArrayOutputStream);
                        byte[] mByte = mByteArrayOutputStream.toByteArray();

                        // Send the Bitmap using a broadcast to inform the activity about the data
                        Intent broadcastIntent = new Intent();
                        broadcastIntent.putExtra("image", mByte);
                        broadcastIntent.setAction("IMAGE_DOWNLOADED_ACTION");
                        getBaseContext().sendBroadcast(broadcastIntent);
                    }

                    @Override
                    public void onError(ANError error) {
                        // handle error
                        Log.d("IntentService Error: ", "Image Download failed" + error.toString());
                    }
                });
    }
}