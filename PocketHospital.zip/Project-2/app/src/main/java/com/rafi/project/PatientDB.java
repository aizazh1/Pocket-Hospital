package com.rafi.project;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

public class PatientDB {

    public static final String TABLE_NAME="patient";
    public static final String FIELD_NAME = "name";
    public static final String FIELD_EMAIL = "email";
    public static final String FIELD_BIRTHDAY = "birthday";
    public static final String FIELD_GENDER = "gender";
    public static final String FIELD_HEIGHT = "height";
    public static final String FIELD_WEIGHT = "weight";
    public static final String FIELD_BLOOD_TYPE = "blood_type";
    public static final String FIELD_ALLERGIES = "allergies";
    public static final String FIELD_PASSWORD = "password";

    public static final String CREATE_TABLE_SQL = "CREATE TABLE "+
            TABLE_NAME+" ("+FIELD_NAME+" text, "+FIELD_EMAIL+" text, "+
            FIELD_BIRTHDAY+" text, "+ FIELD_GENDER+" text, "+ FIELD_HEIGHT +" float,"+ FIELD_WEIGHT +" float, " +
            FIELD_BLOOD_TYPE + " text, "+FIELD_ALLERGIES+" text, "+FIELD_PASSWORD+" text);";
    public static final String DROP_TABLE_SQL = "DROP TABLE if exists "+TABLE_NAME;


    public static List<Patient> getAllPatient(DatabaseHelper db){

        Cursor cursor = db.getAllRecords(TABLE_NAME, null);
        //Cursor cursor  db.getAllRecordsMethod2("SELECT * FROM "+TABLE_NAME, null)
        List<Patient> data=new ArrayList<>();
        Patient anItem = null;
        while (cursor.moveToNext()) {
           String name = cursor.getString(0);
           String email = cursor.getString(1);
           String birthday = cursor.getString(2);
           String gender = cursor.getString(3);
           float height = cursor.getFloat(4);
           float weight = cursor.getFloat(5);
           String blood_type = cursor.getString(6);
           String allergies = cursor.getString(7);
           String password = cursor.getString(8);

            anItem= new Patient(name, email, birthday, gender ,height, weight, blood_type, allergies, password );
            data.add(anItem);
        }

        return data;
    }
    public static List<Patient> findPaitent(DatabaseHelper db, String key) {
        String where = FIELD_NAME + " like '%" + key + "%'";
        Cursor cursor = db.getSomeRecords(TABLE_NAME, null, where);
        List<Patient> data = new ArrayList<>();
        Patient anItem = null;
        while (cursor.moveToNext()) {
            String name = cursor.getString(0);
            String email = cursor.getString(1);
            String birthday = cursor.getString(2);
            String gender = cursor.getString(3);
            float height = cursor.getFloat(4);
            float weight = cursor.getFloat(5);
            String blood_type = cursor.getString(6);
            String allergies = cursor.getString(7);
            String password = cursor.getString(8);

            anItem= new Patient(name, email, birthday, gender ,height, weight, blood_type, allergies, password );
            data.add(anItem);
        }

        return data;
    }

    public static Patient getPaitent(DatabaseHelper db, String searchEmail) {
        String where = FIELD_EMAIL + " = '" + searchEmail + "'";
        Cursor cursor = db.getSomeRecords(TABLE_NAME, null, where);
        Patient Item = null;
        while (cursor.moveToNext()) {
            String name = cursor.getString(0);
            String email = cursor.getString(1);
            String birthday = cursor.getString(2);
            String gender = cursor.getString(3);
            float height = cursor.getFloat(4);
            float weight = cursor.getFloat(5);
            String blood_type = cursor.getString(6);
            String allergies = cursor.getString(7);
            String password = cursor.getString(8);

            Item= new Patient(name, email, birthday, gender ,height, weight, blood_type, allergies, password );
        }

        return Item;
    }

    public static long insertPaitent(DatabaseHelper db, String name, String email, String birthday, String gender ,
                                     float height, float weight,String blood_type,String allergies,String password){
        ContentValues contentValues = new ContentValues( );
        contentValues.put(FIELD_NAME, name);
        contentValues.put(FIELD_EMAIL, email);
        contentValues.put(FIELD_BIRTHDAY, birthday);
        contentValues.put(FIELD_GENDER, gender);
        contentValues.put(FIELD_HEIGHT, height);
        contentValues.put(FIELD_WEIGHT, weight);
        contentValues.put(FIELD_BLOOD_TYPE, blood_type);
        contentValues.put(FIELD_ALLERGIES, allergies);
        contentValues.put(FIELD_PASSWORD, password);

        long res = db.insert(TABLE_NAME,contentValues);

        return res;
    }
    public static boolean updatePaitent(DatabaseHelper db, String name, String email, String birthday, String gender ,
                                             float height, float weight,String blood_type,String allergies,String password){
        ContentValues contentValues = new ContentValues( );
        contentValues.put(FIELD_NAME, name);
        contentValues.put(FIELD_EMAIL, email);
        contentValues.put(FIELD_BIRTHDAY, birthday);
        contentValues.put(FIELD_GENDER, gender);
        contentValues.put(FIELD_HEIGHT, height);
        contentValues.put(FIELD_WEIGHT, weight);
        contentValues.put(FIELD_BLOOD_TYPE, blood_type);
        contentValues.put(FIELD_ALLERGIES, allergies);
        contentValues.put(FIELD_PASSWORD, password);

        String where = FIELD_EMAIL +" = "+ email;

        boolean res = db.update(TABLE_NAME,contentValues,where);

        return res;
    }

    public static boolean deletePatient(DatabaseHelper db, String email){
        String where = FIELD_EMAIL +" = "+ email;

        boolean res = db.delete(TABLE_NAME,where);

        return res;
    }
}
