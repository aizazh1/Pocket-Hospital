package com.rafi.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.WindowManager;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity implements HomeTop.ItemSelectedFromSpinnerListener {

    HomeTop topFragment;
    HomeBottom bottomFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Hiding title bar using code
        getSupportActionBar().hide();
        // Hiding the status bar
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Locking the orientation to Portrait
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        if(topFragment == null){
            topFragment = (HomeTop) getSupportFragmentManager().findFragmentById(R.id.fragmentTop);
        }
        if(bottomFragment == null) {
            bottomFragment = (HomeBottom) getSupportFragmentManager().findFragmentById(R.id.fragmantBottom);
        }

        BottomNavigationView bottomNavigationView = findViewById(R.id.navigation);
        bottomNavigationView.setSelectedItemId(R.id.home);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                if (menuItem.getItemId() == R.id.appointment){
                    startActivity(new Intent(getApplicationContext(), AppointmentView.class));
                    overridePendingTransition(0,0);
                    return true;
                }else if (menuItem.getItemId() == R.id.profile){
                    startActivity(new Intent(getApplicationContext(), Profile.class));
                    overridePendingTransition(0,0);
                    return true;
                }else if (menuItem.getItemId() == R.id.reminder){
                    startActivity(new Intent(getApplicationContext(), ReminderView.class));
                    overridePendingTransition(0,0);
                    return true;
                }
                return false;
            }
        });

    }

    @Override
    public void updateRecyclerView(String dr_name) {
        if(bottomFragment != null && bottomFragment.isInLayout())
            bottomFragment.updateRecycler(dr_name);
    }
}
