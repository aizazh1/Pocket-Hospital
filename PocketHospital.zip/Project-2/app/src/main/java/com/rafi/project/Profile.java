package com.rafi.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.w3c.dom.Text;

public class Profile extends AppCompatActivity {

    TextView pName, pBirthday, pEmail, pAllergies, pBloodType, pHeight, pWeight;
    ImageView imageView,imv;
    private IntentFilter mIntentFilter;
    private ImageView mImageView;
    private Intent mIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Hiding title bar using code
        getSupportActionBar().hide();
        // Hiding the status bar
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Locking the orientation to Portrait
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        mImageView = (ImageView) findViewById(R.id.imv);
        mIntentFilter = new IntentFilter();
        mIntentFilter.addAction("IMAGE_DOWNLOADED_ACTION");
        registerReceiver(mIntentReceiver, mIntentFilter);

        BottomNavigationView bottomNavigationView = findViewById(R.id.navigation);
        bottomNavigationView.setSelectedItemId(R.id.profile);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                if (menuItem.getItemId() == R.id.appointment){
                    startActivity(new Intent(getApplicationContext(), AppointmentView.class));
                    overridePendingTransition(0,0);
                    return true;
                }else if (menuItem.getItemId() == R.id.home){
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    overridePendingTransition(0,0);
                    return true;
                }else if (menuItem.getItemId() == R.id.reminder){
                    startActivity(new Intent(getApplicationContext(), ReminderView.class));
                    overridePendingTransition(0,0);
                    return true;
                }
                return false;
            }
        });

        pName = findViewById(R.id.tvPName);
        pEmail = findViewById(R.id.tvPEmail);
        pBirthday = findViewById(R.id.tvPBirthday);
        pWeight = findViewById(R.id.tvPWeight);
        pHeight = findViewById(R.id.tvPHeight);
        pAllergies = findViewById(R.id.tvPAllergies);
        pBloodType = findViewById(R.id.tvPBloodType);
        imageView = findViewById(R.id.profileImg);

        Patient p = Commons.user;

        pName.setText(p.getName());
        pEmail.setText(p.getEmail());
        pBirthday.setText(p.getBirthday());
        pAllergies.setText(p.getAllergies());
        pBloodType.setText(p.getBlood_type());
        pWeight.setText(String.valueOf(p.getWeight()));
        pHeight.setText(String.valueOf(p.getHeight()));

        if (p.getGender().equalsIgnoreCase("M")){
            imageView.setImageResource(R.drawable.male);
        }else {
            imageView.setImageResource(R.drawable.male);
        }




    }
    public void onClickBtn(View view) {
        mIntent = new Intent(getBaseContext(), MyIntentService.class);
        mIntent.putExtra("url", "https://i.pinimg.com/474x/a8/69/40/a86940a4ed8a69539b341f3c414c47b3--qr-codes-crossword.jpg");
        startService(mIntent);
    }

    private BroadcastReceiver mIntentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent){
            // Storing the received data into a Bundle
            Bundle mBundle = intent.getExtras();
            byte[] mByte = mBundle.getByteArray("image");

            // Converting the byte array into a Bitmap
            Bitmap mBitmap = BitmapFactory.decodeByteArray(mByte, 0, mByte.length);
            mImageView.setImageBitmap(mBitmap);
        }};
}
