package com.rafi.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class ReminderView extends AppCompatActivity {

    private RecyclerView recyclerViewRem;
    LinearLayoutManager layoutManager;
    RecyclerViewAdapterReminder adapter;
    DatabaseHelper databaseHelper;
    Dialog customDialog2;
    Button addReminder;

    private ArrayList<Reminder> reminderValues = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder);

        // Hiding title bar using code
        getSupportActionBar().hide();
        // Hiding the status bar
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Locking the orientation to Portrait
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        BottomNavigationView bottomNavigationView = findViewById(R.id.navigation);
        bottomNavigationView.setSelectedItemId(R.id.reminder);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                if (menuItem.getItemId() == R.id.appointment){
                    startActivity(new Intent(getApplicationContext(), AppointmentView.class));
                    overridePendingTransition(0,0);
                    return true;
                }else if (menuItem.getItemId() == R.id.profile){
                    startActivity(new Intent(getApplicationContext(), Profile.class));
                    overridePendingTransition(0,0);
                    return true;
                }else if (menuItem.getItemId() == R.id.home){
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    overridePendingTransition(0,0);
                    return true;
                }
                return false;
            }
        });

        addReminder = findViewById(R.id.btnAddRem);

        recyclerViewRem = findViewById(R.id.rvReminder);
        layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerViewRem.setLayoutManager(layoutManager);

        getDataPrep();
        adapter = new RecyclerViewAdapterReminder(this,reminderValues, recyclerViewRem);
        recyclerViewRem.setAdapter(adapter);

        addReminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayDialog();
            }
        });
    }



    public void getDataPrep(){
        DatabaseHelper dbHelper;
        dbHelper = new DatabaseHelper(this);

        Commons.userReminder = ReminderDB.getReminder(dbHelper);
        reminderValues = Commons.userReminder;
    }

    public void displayDialog(){
        databaseHelper = new DatabaseHelper(this);

        final EditText etMedName, etTime, etQuantity, etTimequantity;
        Button btnAdd, btnClose;

        customDialog2 = new Dialog(this);
        customDialog2.setContentView(R.layout.dialog_rem );

        etMedName =  customDialog2.findViewById(R.id.etDialogMedName );
        etTime = customDialog2.findViewById(R.id.etDialogTiming);
        etQuantity = customDialog2.findViewById(R.id.etDialogQuantity);
        etTimequantity = customDialog2.findViewById(R.id.etDialogTimequantity);

        btnAdd = customDialog2.findViewById(R.id.btnDialogAddRem);
        btnClose =  customDialog2.findViewById(R.id.btnDialogCloseRem);


        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String medName= etMedName.getText().toString();
                int times, quantity;
                if (etTime.getText().toString().equals("")){
                    times=0;
                }else {
                    times = Integer.parseInt(etTime.getText().toString());
                }
                if (etQuantity.getText().toString().equals("")){
                    quantity=0;
                }else {
                    quantity = Integer.parseInt(etQuantity.getText().toString());
                }
                String timeQuantity = etTimequantity.getText().toString();

                if (medName.equals("") || timeQuantity.equals("")|| times==0 || quantity==0){
                    Commons.displayToast(ReminderView.this, "Enter all the required info");
                }else{
                    ReminderDB.insertReminder(databaseHelper , Commons.user.getEmail() ,medName , times ,quantity, timeQuantity);
                    getDataPrep();
                    adapter = new RecyclerViewAdapterReminder(ReminderView.this,reminderValues, recyclerViewRem);
                    recyclerViewRem.setAdapter(adapter);
                    customDialog2.dismiss();
                }
            }
        });


        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                customDialog2.dismiss();
            }
        });

        customDialog2.show();
    }
}
