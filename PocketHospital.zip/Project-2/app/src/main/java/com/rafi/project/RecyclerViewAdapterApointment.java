package com.rafi.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerViewAdapterApointment extends RecyclerView.Adapter<RecyclerViewAdapterApointment.RecyclerViewAdapterApointmentItemHolder> {
    private Context context;
    private ArrayList<Appointment> recyclerItemValues;
    private RecyclerView recyclerView;

    DatabaseHelper helper;


    public RecyclerViewAdapterApointment(Context context, ArrayList<Appointment> values, RecyclerView recyclerView){
        this.context = context;
        this.recyclerItemValues = values;
        this.recyclerView = recyclerView;
    }

    @NonNull
    @Override
    public RecyclerViewAdapterApointmentItemHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflator = LayoutInflater.from(viewGroup.getContext());
        View itemView = inflator.inflate(R.layout.rv_appointment_layout, viewGroup, false);
        RecyclerViewAdapterApointmentItemHolder mViewHolder = new RecyclerViewAdapterApointmentItemHolder(itemView);
        return mViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapterApointmentItemHolder recyclerViewAdapterApointmentItemHolder, int i) {
        final Appointment sm = recyclerItemValues.get(i);

        final int pos = i;

        recyclerViewAdapterApointmentItemHolder.tv_drname.setText(sm.getDr_name());
        recyclerViewAdapterApointmentItemHolder.tv_time.setText(sm.getTime());
        recyclerViewAdapterApointmentItemHolder.tv_date.setText(sm.getDate());

        recyclerViewAdapterApointmentItemHolder.delimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recyclerItemValues.remove(pos);
                notifyItemRemoved(pos);

                notifyItemRangeChanged(pos, recyclerItemValues.size());

                helper = new DatabaseHelper(context);
                AppointmentDB.deleteAppointment(helper, sm);

                Commons.displayToast(context, "Appointment for "+ sm.getDr_name() +"has been deleted");
            }
        });

    }

    @Override
    public int getItemCount() {
        return recyclerItemValues.size();
    }

     class RecyclerViewAdapterApointmentItemHolder extends  RecyclerView.ViewHolder{
        TextView tv_drname;
        TextView tv_date;
        TextView tv_time;
        ImageView delimg;
        LinearLayout parentLayout;

        public RecyclerViewAdapterApointmentItemHolder(@NonNull View itemView) {
            super(itemView);
            tv_drname = itemView.findViewById(R.id.tv_drname);
            tv_date = itemView.findViewById(R.id.tv_date);
            tv_time= itemView.findViewById(R.id.tv_time);
            delimg = itemView.findViewById(R.id.imgDeleteApp);
            parentLayout = itemView.findViewById(R.id.itemLinearLayout);
        }
    }


}
