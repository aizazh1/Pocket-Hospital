package com.rafi.project;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

public class ReminderDB {

    public static final String TABLE_NAME="reminder";
    public static final String FIELD_EMAIL = "email";
    public static final String FIELD_MEDICINE_NAME = "medicine_name";
    public static final String FIELD_TIME = "time";
    public static final String FIELD_QUANTITY = "quantity";
    public static final String FIELD_TIMEQUANTITY = "timequantity";

    public static final String CREATE_TABLE_SQL = "CREATE TABLE "+
            TABLE_NAME+" ("+FIELD_EMAIL+" text, "+ FIELD_MEDICINE_NAME+" text, "+ FIELD_TIME+" integer, "+
            FIELD_QUANTITY +" integer,"+ FIELD_TIMEQUANTITY +" text);";
    public static final String DROP_TABLE_SQL = "DROP TABLE if exists "+TABLE_NAME;


    public static List<Reminder> getAllReminder(DatabaseHelper db){

        Cursor cursor = db.getAllRecords(TABLE_NAME, null);
        //Cursor cursor  db.getAllRecordsMethod2("SELECT * FROM "+TABLE_NAME, null)
        List<Reminder> data = new ArrayList<>();
        Reminder anItem = null;
        while (cursor.moveToNext()) {
            String email = cursor.getString(0);
            String medicine_name = cursor.getString(1);
            int time = cursor.getInt(2);
            int quantity = cursor.getInt(3);
            String timequantity = cursor.getString(4);

            anItem= new Reminder(email, medicine_name, time, quantity, timequantity);
            data.add(anItem);
        }

        return data;
    }

    public static List<Reminder> findReminder(DatabaseHelper db, String key, String searchemail) {
        String where = FIELD_MEDICINE_NAME + " like '%" + key + "%' AND " + FIELD_EMAIL + " = '"+ searchemail+"'";
        Cursor cursor = db.getSomeRecords(TABLE_NAME, null, where);
        List<Reminder> data = new ArrayList<>();
        Reminder anItem = null;

        while (cursor.moveToNext()) {
            String email = cursor.getString(0);
            String medicine_name = cursor.getString(1);
            int time = cursor.getInt(2);
            int quantity = cursor.getInt(3);
            String timequantity = cursor.getString(4);

            anItem= new Reminder(email, medicine_name, time, quantity, timequantity);
            data.add(anItem);
        }
        return data;
    }

    public static ArrayList<Reminder> getReminder(DatabaseHelper db) {
        String where = FIELD_EMAIL + " = '" + Commons.user.getEmail() + "'";
        Cursor cursor = db.getSomeRecords(TABLE_NAME, null, where);

        ArrayList<Reminder> data = new ArrayList<>();
        Reminder Item = null;
        while (cursor.moveToNext()) {
            String email = cursor.getString(0);
            String medicine_name = cursor.getString(1);
            int time = cursor.getInt(2);
            int quantity = cursor.getInt(3);
            String timequantity = cursor.getString(4);

            Item = new Reminder(email, medicine_name, time, quantity, timequantity);
            data.add(Item);
        }

        return data;
    }

    public static long insertReminder(DatabaseHelper db, String email, String medicine_name, int time, int quantity, String timequantity){
        ContentValues contentValues = new ContentValues( );
        contentValues.put(FIELD_EMAIL, email);
        contentValues.put(FIELD_MEDICINE_NAME, medicine_name);
        contentValues.put(FIELD_TIME, time);
        contentValues.put(FIELD_QUANTITY, quantity);
        contentValues.put(FIELD_TIMEQUANTITY, timequantity);

        long res = db.insert(TABLE_NAME,contentValues);

        return res;
    }


    public static boolean deleteReminder(DatabaseHelper db, Reminder m){
        String email = m.getEmail();
        String medicine = m.getMedicine_name();
        String where = FIELD_EMAIL +" = '"+ email + "' AND " + FIELD_MEDICINE_NAME +" = '"+ medicine+"'";

        boolean res = db.delete(TABLE_NAME,where);

        return res;
    }
}
