package com.rafi.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class RecyclerViewAdapterReminder extends RecyclerView.Adapter<RecyclerViewAdapterReminder.RecyclerViewItemHolder> {
    private Context context;
    private ArrayList<Reminder> recyclerItemValues;
    private RecyclerView recyclerView;
    DatabaseHelper helper;


    public RecyclerViewAdapterReminder(Context context, ArrayList<Reminder> values, RecyclerView recyclerView){
        this.context = context;
        this.recyclerItemValues = values;
        this.recyclerView = recyclerView;
    }

    @NonNull
    @Override
    public RecyclerViewItemHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflator = LayoutInflater.from(viewGroup.getContext());
        View itemView = inflator.inflate(R.layout.rv_reminder_layout, viewGroup, false);
        RecyclerViewItemHolder mViewHolder = new RecyclerViewItemHolder(itemView);
        return mViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewItemHolder myRecyclerViewItemHolder, int i) {
        final Reminder rem = recyclerItemValues.get(i);
        final int pos = i;

        myRecyclerViewItemHolder.tv_medicine.setText(rem.getMedicine_name());
        myRecyclerViewItemHolder.tv_timing.setText(""+rem.getTiming());
        myRecyclerViewItemHolder.tv_quantity.setText(""+rem.getQuantity());
        myRecyclerViewItemHolder.tv_timequantity.setText(rem.getTimequantity());

        myRecyclerViewItemHolder.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                recyclerItemValues.remove(pos);
                notifyItemRemoved(pos);

                notifyItemRangeChanged(pos, recyclerItemValues.size());

                helper = new DatabaseHelper(context);
                ReminderDB.deleteReminder(helper, rem);
                Commons.displayToast(context, "Reminder for "+rem.medicine_name +"has been deleted");
            }
        });

    }

    @Override
    public int getItemCount() {
        return recyclerItemValues.size();
    }

     class RecyclerViewItemHolder extends  RecyclerView.ViewHolder{
        TextView tv_medicine;
        TextView tv_quantity;
        TextView tv_timing;
        TextView tv_timequantity;
        ImageView imageView;
        LinearLayout parentLayout;

        public RecyclerViewItemHolder(@NonNull View itemView) {
            super(itemView);
            tv_medicine = itemView.findViewById(R.id.tv_medicineName);
            tv_quantity = itemView.findViewById(R.id.tv_quantiy);
            tv_timing = itemView.findViewById(R.id.tv_timing);
            tv_timequantity = itemView.findViewById(R.id.tv_timequantity);
            imageView = itemView.findViewById(R.id.imgDeleteRem);
            parentLayout = itemView.findViewById(R.id.itemLinearLayout);
        }
    }

}
