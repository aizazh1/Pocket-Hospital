package com.rafi.project;

import android.content.ContentValues;
import android.database.Cursor;

import java.sql.Array;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDB {

    public static final String TABLE_NAME="appointment";
    public static final String FIELD_EMAIL = "email";
    public static final String FIELD_ID = "id";
    public static final String FIELD_DR_NAME = "dr_name";
    public static final String FIELD_DATE = "date";
    public static final String FIELD_TIME = "time";

    public static final String CREATE_TABLE_SQL = "CREATE TABLE "+
            TABLE_NAME+" ("+FIELD_EMAIL+" text, "+ FIELD_ID+" integer "+ FIELD_DR_NAME+" text, "
            + FIELD_DATE +" text,"+ FIELD_TIME +" text);";
    public static final String DROP_TABLE_SQL = "DROP TABLE if exists "+TABLE_NAME;


    public static ArrayList<Appointment> getAppointment(DatabaseHelper db){
        String where = FIELD_EMAIL + " = '" + Commons.user.getEmail() + "'";;
        Cursor cursor = db.getSomeRecords(TABLE_NAME, null, where);
        //Cursor cursor  db.getAllRecordsMethod2("SELECT * FROM "+TABLE_NAME, null)
        ArrayList<Appointment> data=new ArrayList<>();
        Appointment anItem = null;
        while (cursor.moveToNext()) {
            String email = cursor.getString(0);
            int id = cursor.getInt(1);
            String dr_name = cursor.getString(2);
            String date = cursor.getString(3);
            String time = cursor.getString(4);

            anItem= new Appointment(email, id, dr_name, date, time);
            data.add(anItem);
        }

        return data;
    }

    public static ArrayList<Appointment> getAppointmentDoc(DatabaseHelper db, String drName){
        String where = FIELD_EMAIL + " = '" + Commons.user.getEmail() + "' AND " + FIELD_DR_NAME + " = '" + drName + "'";;
        Cursor cursor = db.getSomeRecords(TABLE_NAME, null, where);
        //Cursor cursor  db.getAllRecordsMethod2("SELECT * FROM "+TABLE_NAME, null)
        ArrayList<Appointment> data=new ArrayList<>();
        Appointment anItem = null;
        while (cursor.moveToNext()) {
            String email = cursor.getString(0);
            int id = cursor.getInt(1);
            String dr_name = cursor.getString(2);
            String date = cursor.getString(3);
            String time = cursor.getString(4);

            anItem= new Appointment(email, id, dr_name, date, time);
            data.add(anItem);
        }

        return data;
    }

    public static long insertAppointment(DatabaseHelper db, String email, /*int id,*/ String dr_name, String date,String time){
        ContentValues contentValues = new ContentValues( );
        contentValues.put(FIELD_EMAIL, email);
        //contentValues.put(FIELD_ID, id);
        contentValues.put(FIELD_DR_NAME, dr_name);
        contentValues.put(FIELD_DATE, date);
        contentValues.put(FIELD_TIME, time);

        long res = db.insert(TABLE_NAME,contentValues);

        return res;
    }

    public static boolean deleteAppointment(DatabaseHelper db, Appointment a){

        String where = FIELD_EMAIL +" = '"+ Commons.user.getEmail() + "' AND " + FIELD_DR_NAME +" = '"+ a.getDr_name() +
                "' AND " + FIELD_TIME +" = '"+ a.getTime() + "' AND " + FIELD_DATE +" = '"+ a.getDate()+"'" ;

        boolean res = db.delete(TABLE_NAME,where);

        return res;
    }
}
