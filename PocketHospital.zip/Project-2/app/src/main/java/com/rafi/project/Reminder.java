package com.rafi.project;

public class Reminder {
    String email;
    String medicine_name;
    int time;
    int quantity;
    String timequantity;

    public Reminder(String email ,String medicine_name, int time, int quantity, String timequantity) {
        this.email = email;
        this.medicine_name = medicine_name;
        this.time = time;
        this.quantity = quantity;
        this.timequantity = timequantity;
    }

    public String getMedicine_name() {
        return medicine_name;
    }

    public void setMedicine_name(String medicine_name) {
        this.medicine_name = medicine_name;
    }

    public int getTiming() {
        return time;
    }

    public void setTiming(int time) {
        this.time = time;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getTimequantity() {
        return timequantity;
    }

    public void setTimequantity(String timequantity) {
        this.timequantity = timequantity;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
