package com.rafi.project;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HomeTop extends Fragment {

    interface ItemSelectedFromSpinnerListener{
        public void updateRecyclerView(String dr_name);
    }

    ItemSelectedFromSpinnerListener listener;
    Spinner spinnerAppointment;
    Button btnAdd;
    DatabaseHelper dbHelper;
    boolean isDefaultSelection = true;
    
    Dialog customDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_appointment_top, container, false);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if(context instanceof  ItemSelectedFromSpinnerListener){
            listener =  (ItemSelectedFromSpinnerListener) context;
        }
        else
            throw new ClassCastException(context.toString()+" must be implemented ItemSelectedFromSpinnerListener");
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        customDialog = new Dialog(getContext());
        spinnerAppointment = view.findViewById(R.id.spinnerApp);
        btnAdd = view.findViewById(R.id.btnAddApp);

        spinnerAppointment.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(isDefaultSelection)
                    isDefaultSelection = false;
                else{
                    String selectedDr= spinnerAppointment.getSelectedItem().toString();
                    Toast.makeText(getActivity(), "Appintments for Dr. "+ selectedDr, Toast.LENGTH_LONG).show();

                    listener.updateRecyclerView(selectedDr);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String selectedDr= spinnerAppointment.getSelectedItem().toString();
                if (selectedDr.equalsIgnoreCase("all")){
                    Commons.displayToast(getActivity(), "Please select the Doctor you want to add appointment for ");
                }else{
                    displayDialog();
                }
            }
        });

        spinnerAppointment.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Commons.displayToast(getContext(), "Long pressed the spinner");

                String selectedDr= spinnerAppointment.getSelectedItem().toString();
                if (selectedDr.equalsIgnoreCase("all")){
                    Commons.displayToast(getActivity(), "Please select the Doctor you want to see information for ");
                }else{
                    //show the selected doctor info
                }
                return false;
            }
        });



    }

    public void displayDialog(){
        dbHelper = new DatabaseHelper(getContext());

        final EditText etDocName, etTime, etDate;
        Button btnAdd, btnClose;

        customDialog = new Dialog(getContext());
        customDialog.setContentView(R.layout.dialog_home );

        etDocName =  customDialog.findViewById(R.id.etDialogDoctorName );
        etTime = customDialog.findViewById(R.id.etDialogTime);
        etDate = customDialog.findViewById(R.id.etDialogDate);

        btnAdd = customDialog.findViewById(R.id.btnDialogAddApp);
        btnClose =  customDialog.findViewById(R.id.btnDialogCloseApp);

        String doc = spinnerAppointment.getSelectedItem().toString();
        etDocName.setText(doc);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String docName= etDocName.getText().toString();
                String time = etTime.getText().toString();
                String date = etDate.getText().toString();

                if (docName.equals("") || time.equals("") || date.equals("")){
                    Commons.displayToast(getContext(), "Enter all the required info");
                }else{
                    AppointmentDB.insertAppointment(dbHelper , Commons.user.getEmail() ,docName , time ,date);
                    listener.updateRecyclerView(etDocName.getText().toString());
                    customDialog.dismiss();
                }
            }
        });


        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.updateRecyclerView(etDocName.getText().toString());
                customDialog.dismiss();
            }
        });

        customDialog.show();
    }



}
