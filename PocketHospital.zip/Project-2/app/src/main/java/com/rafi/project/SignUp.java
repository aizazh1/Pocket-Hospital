package com.rafi.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.RadioButton;

import com.google.android.material.textfield.TextInputEditText;

public class SignUp extends AppCompatActivity {
    TextInputEditText et_name;
    TextInputEditText et_email;
    TextInputEditText et_birthday;
    TextInputEditText et_height;
    TextInputEditText et_weight;
    TextInputEditText et_blood_type;
    TextInputEditText et_allergies;
    TextInputEditText et_pass;
    RadioButton rbMale;

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        // Hiding title bar using code
        getSupportActionBar().hide();
        // Hiding the status bar
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Locking the orientation to Portrait
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        et_name = findViewById(R.id.su_name);
        et_email = findViewById(R.id.su_email);
        et_birthday = findViewById(R.id.su_birthday);
        rbMale = findViewById(R.id.rb_male);
        et_blood_type = findViewById(R.id.su_blood_type);
        et_allergies = findViewById(R.id.su_allergies);
        et_height = findViewById(R.id.su_height);
        et_weight = findViewById(R.id.su_weight);
        et_pass = findViewById(R.id.su_pass);


    }

    public void SignIn(View view) {
        startActivity(new Intent(this, SignIn.class));
    }

    public void SignUp(View view) {

        databaseHelper = new DatabaseHelper(this);
        float weight;
        float height;
        String gender;
        String name = et_name.getText().toString();
        String email = et_email.getText().toString();
        String birthday = et_birthday.getText().toString();
        String blood_type = et_blood_type.getText().toString();
        String allergies = et_allergies.getText().toString();
        String password = et_pass.getText().toString();
        if (et_height.getText().toString().equals("")){
            height = 0;
        }else {
            height = Float.parseFloat(et_height.getText().toString());
        }

        if (et_height.getText().toString().equals("")){
            weight = 0;
        }else {
            weight = Float.parseFloat(et_weight.getText().toString());
        }

        if (rbMale.isSelected()){
            gender = "M";
        }else{
            gender = "F";
        }


        if (name.equals("") ||  email.equals("")|| birthday.equals("") || blood_type.equals("")||
                allergies.equals("") || password.equals("")){
            Commons.displayToast(this, "Please enter all the required information");
        }else {
            Long successAdded = PatientDB.insertPaitent(databaseHelper, name, email, birthday, gender, height,weight, blood_type,allergies,password);
            Commons.displayToast(this,successAdded+"");
            if(successAdded != -1){
               Commons.displayToast(this, "Successfully added");
               startActivity(new Intent(this, SignIn.class));
            }else{
                Commons.displayToast(this, "Email "+email+" is already registered!");
            }
        }

    }
}
