package com.rafi.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;

import com.google.android.material.textfield.TextInputEditText;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class SignIn extends AppCompatActivity {

    private SharedPreferences mSharedPreferences;
    private String prefName = "MyPrefFile";

    TextInputEditText et_email;
    TextInputEditText et_pass;
    CheckBox cb_rem;
    private static final String KEY_EMAIL = "email";
    private static final String KEY_PASS = "pass";

    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        et_email = findViewById(R.id.TIET_email);
        et_pass = findViewById(R.id.TIET_pass);
        cb_rem = findViewById(R.id.cb_rem);

        // Hiding title bar using code
        getSupportActionBar().hide();
        // Hiding the status bar
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Locking the orientation to Portrait
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        mSharedPreferences = getSharedPreferences(prefName, MODE_PRIVATE);
        et_email.setText(mSharedPreferences.getString(KEY_EMAIL, ""));
        et_pass.setText(mSharedPreferences.getString(KEY_PASS, ""));



        //Copy database from the assets/ folder to the data/data/databases/ folder. İf ıt exist, there is no need to copy it
        try {
            String fileToDatabase = "/data/data/" + getPackageName() + "/databases/"+DatabaseHelper.DATABASE_NAME;
            File file = new File(fileToDatabase);
            File pathToDatabasesFolder = new File("/data/data/" + getPackageName() + "/databases/");

            if (!file.exists()) {
                //Commons.displayToast(this, "running");
                pathToDatabasesFolder.mkdirs();
                CopyDB( getResources().getAssets().open(DatabaseHelper.DATABASE_NAME), new FileOutputStream(fileToDatabase));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        dbHelper = new DatabaseHelper(this);

    }




    public void SignIn(View view) {

        String email = et_email.getText().toString();
        String pass = et_pass.getText().toString();

        Patient found = PatientDB.getPaitent(dbHelper, email);

        if (found != null){
            Commons.user = found;
            if (found.getPass().equals(pass)){
                if (cb_rem.isChecked()) {
                    mSharedPreferences = getSharedPreferences(prefName, MODE_PRIVATE);
                    SharedPreferences.Editor editor = mSharedPreferences.edit();

                    editor.putString(KEY_EMAIL, et_email.getText().toString());
                    editor.putString(KEY_PASS, et_pass.getText().toString());
                    editor.commit();
                    Commons.displayToast(this, "Email & Password saved successfully!");
                }
                final MediaPlayer soundclick = MediaPlayer.create(this, R.raw.mouse_click );
                soundclick.start();
                startActivity(new Intent(this, MainActivity.class));
            }
        }else {
            Commons.displayToast(this, "Email/Password not found");
        }
    }

    public void SignUp(View view) {
        startActivity(new Intent(this, SignUp.class));
        finish();
    }

    public void CopyDB(InputStream inputStream, OutputStream outputStream) throws IOException {
        // Copy 1K bytes at a time
        byte[] buffer = new byte[1024];
        int length;

        while ((length = inputStream.read(buffer)) > 0) {
            outputStream.write(buffer, 0, length);
        }
        inputStream.close();
        outputStream.close();
    }

    @Override
    protected void onStop() {
        super.onStop();
        dbHelper.close();
    }
}
