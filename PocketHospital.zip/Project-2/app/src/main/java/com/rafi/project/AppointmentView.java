package com.rafi.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class AppointmentView extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private MyRecyclerViewAdapter mRecyclerAdapter;
    Dialog customDialog;

    // JSON related
    private String jsonStr;
    private JSONArray doctors;
    private JSONObject doctorJSONObject;

    EditText etKey;
    String key="";
    // ArrayList containing HashMap for RecyclerView
    private ArrayList<Doctor> mArrayList;
    TextView tvName,tvTiming;
    Button btnAdd;

    public static final String TAG_DOCTORS = "doctors";
    public static final String TAG_NAME = "name";
    public static final String TAG_GENDER = "gender";
    public static final String TAG_SPECIAL = "specialisation";
    public static final String TAG_IMG = "picURL";
    public static final String TAG_EMAIL = "email";
    public static final String TAG_NUMBER = "mobile";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);

        // Hiding title bar using code
        getSupportActionBar().hide();
        // Hiding the status bar
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Locking the orientation to Portrait
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        BottomNavigationView bottomNavigationView = findViewById(R.id.navigation);
        bottomNavigationView.setSelectedItemId(R.id.appointment);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                if (menuItem.getItemId() == R.id.home){
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    overridePendingTransition(0,0);
                    return true;
                }else if (menuItem.getItemId() == R.id.profile){
                    startActivity(new Intent(getApplicationContext(), Profile.class));
                    overridePendingTransition(0,0);
                    return true;
                }else if (menuItem.getItemId() == R.id.reminder){
                    startActivity(new Intent(getApplicationContext(), ReminderView.class));
                    overridePendingTransition(0,0);
                    return true;
                }
                return false;
            }
        });

        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerViewDoctors);

        mLayoutManager = new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false);
        mRecyclerView.setLayoutManager(mLayoutManager);
    }
    public void onClick(View v) {

        mArrayList = new ArrayList<Doctor>();


        // Reading the JSON file from the raw folder and storing it in a String
        //jsonStr = loadFileFromRaw("books");
        //Log.d("TAG", "\n" + jsonStr);

        // Reading the JSON file from the assets folder and storing it in a String
        jsonStr = loadFileFromAssets("doctors.json");
        Log.d("TAG", "\n" + jsonStr);

        // Call to AsyncTask
        new getDoctors().execute();

    }

    private class getDoctors extends AsyncTask<Void, Void, Void> {

        // Main job should be done here
        @Override
        protected Void doInBackground(Void... params) {
            //Log.d("TAG", "HERE.....");

            if (jsonStr != null) {
                try {
                    doctorJSONObject = new JSONObject(jsonStr);
                    // Getting JSON Array
                    doctors = doctorJSONObject.getJSONArray(TAG_DOCTORS);


                    // looping through all books
                    for (int i = 0; i < doctors.length(); i++) {

                        JSONObject jsonObj = doctors.getJSONObject(i);

                        Thread.sleep(2000);//This is here only to simulate parsing json takes time so that ProgressBar execution can be displayed better

                        String name = jsonObj.getString(TAG_NAME);
                        String special = jsonObj.getString(TAG_SPECIAL);
                        String email = jsonObj.getString(TAG_EMAIL);
                        String gender = jsonObj.getString(TAG_EMAIL);
                        int number = jsonObj.getInt(TAG_NUMBER);
                        String img = jsonObj.getString(TAG_IMG);

                        Doctor doctor = new Doctor(i+1, name,  email,  gender,  special,  img,  "SAT-THU", number);

                        Log.d("KEY", key+" "+name);
                        if(key.isEmpty())
                            mArrayList.add(doctor);
                        else if(name.toLowerCase().contains(key.toLowerCase()))
                            mArrayList.add(doctor);
                    }
                } catch (JSONException ee) {
                    ee.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        // What do you want to do after doInBackground() finishes
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            // Dismiss the progress dialog


            if (mArrayList != null) {
                mRecyclerAdapter = new MyRecyclerViewAdapter(AppointmentView.this, mArrayList);
                Toast.makeText(AppointmentView.this, "I AM HERE", Toast.LENGTH_LONG).show();
                mRecyclerView.setAdapter(mRecyclerAdapter);

            } else
                Toast.makeText(AppointmentView.this, "Not Found", Toast.LENGTH_LONG).show();
        }

    }

    private String loadFileFromRaw(String fileName) {
        String fileContent = null;
        try {
            InputStream is = getResources().openRawResource(
                    getResources().getIdentifier(fileName,
                            "raw", getPackageName()));
            int size = is.available();
            byte[] buffer = new byte[size];

            is.read(buffer);
            is.close();

            fileContent = new String(buffer, "UTF-8");

        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return fileContent;
    }

    private String loadFileFromAssets(String fileName) {
        String fileContent = null;
        try {
            InputStream is = getBaseContext().getAssets().open(fileName);

            int size = is.available();
            byte[] buffer = new byte[size];

            is.read(buffer);
            is.close();

            fileContent = new String(buffer, "UTF-8");

        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return fileContent;
    }
    public void displayDialog(final String msg,String time,String day){

        customDialog = new Dialog(this);

        customDialog.setContentView(R.layout.dialog_app);
        tvName =  customDialog.findViewById(R.id.tvDialName);
        btnAdd = customDialog.findViewById(R.id.btnDialogAddApp);
        tvTiming = customDialog.findViewById(R.id.tvDialTime);
        tvName.setText(msg+"");
        tvTiming.setText(day+""+time);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                customDialog.dismiss();
            }
        });
        customDialog.show();;
    }
}
