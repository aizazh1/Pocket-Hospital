package com.rafi.project;

public class Doctor {

    int id;
    String name, email , gender, spec,pic, days;
    int phone;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getSpec() {
        return spec;
    }

    public void setSpec(String spec) {
        this.spec = spec;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getDays() {
        return days;
    }

    public void setDays(String days) {
        this.days = days;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public Doctor(int id, String name, String email, String gender, String spec, String pic, String days, int phone) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.gender = gender;
        this.spec = spec;
        this.pic = pic;
        this.days = days;
        this.phone = phone;
    }
}
